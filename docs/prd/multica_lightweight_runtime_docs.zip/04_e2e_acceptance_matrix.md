# Multica 端到端验收用例矩阵

## 1. 验收级别

| 级别 | 含义 |
|---|---|
| P0 | 不通过则目标系统不可运行 |
| P1 | 核心可靠性或安全能力 |
| P2 | 可用性和管理能力 |

## 2. Daemon 与 Runtime

| ID | 级别 | 场景 | 前置条件 | 操作 | 预期 |
|---|---|---|---|---|---|
| DR-01 | P0 | Desktop 启动 Daemon | 用户已登录 | 打开 Desktop | Daemon 自动启动并 Health Ready |
| DR-02 | P0 | Runtime 注册 | 本地安装 Codex/Claude | Daemon 启动 | Server 出现对应 Runtime |
| DR-03 | P1 | Runtime 离线 | Runtime 已注册 | 停止 Daemon | Web 显示 Offline |
| DR-04 | P1 | Runtime 恢复 | Runtime Offline | 重启 Daemon | 原 Runtime 恢复或正确重新注册 |
| DR-05 | P1 | 多 Runtime | 一台设备多个 Provider | 启动 Daemon | Web 按设备展示多个 Runtime |
| DR-06 | P1 | Workspace 隔离 | 两个 Workspace | Daemon 使用 WS-A Token | 不得访问 WS-B Runtime/Task |

## 3. Agent

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| AG-01 | P0 | 创建 Agent | 选择有效 Runtime 创建 | 创建成功且绑定 Runtime |
| AG-02 | P0 | Runtime 必填 | 不选 Runtime 提交 | 400/明确错误 |
| AG-03 | P1 | 跨 Workspace Runtime | 传入其他 Workspace Runtime | 拒绝 |
| AG-04 | P1 | Runtime Offline | 绑定 Offline Runtime 执行 | 明确阻塞或保留队列，不静默丢失 |
| AG-05 | P1 | Archive Agent | 归档后执行 | 拒绝 |
| AG-06 | P1 | 私有 Agent | 非授权用户调用 | 403 |
| AG-07 | P2 | Skills/MCP | 创建并配置 Skills/MCP | Claim Payload 正确包含 |

## 4. Direct Chat

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| CH-01 | P0 | 新建 Chat | 选择 Agent 发送消息 | 创建 Session、Message、Task |
| CH-02 | P0 | Claim Chat Task | Daemon Claim | `issue_id` 为空，`chat_session_id` 有效 |
| CH-03 | P0 | Streaming | Runtime 输出流 | UI 实时展示 |
| CH-04 | P0 | Complete | Runtime 完成 | 创建 Assistant Message |
| CH-05 | P1 | Fail | Runtime 返回错误 | 创建可见 Failure Message |
| CH-06 | P1 | Cancel Queued | 用户取消 | Task Cancelled，输入可恢复 |
| CH-07 | P1 | Cancel Running | 用户取消 | Daemon 收到取消并确认 |
| CH-08 | P1 | Resume | 连续发送两轮 | 使用安全 Session/WorkDir |
| CH-09 | P1 | Runtime Missing | Agent 无 Runtime | 409，禁止执行 |
| CH-10 | P2 | Archive Session | 归档后发送 | 拒绝，历史保留 |

## 5. Squad 配置

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| SQ-01 | P0 | 创建 Squad | 选择 Leader 创建 | Squad 创建成功 |
| SQ-02 | P0 | Leader 自动入组 | 创建 Squad | Leader Member Role=`leader` |
| SQ-03 | P0 | 添加 Agent Member | 添加成员和 Role | 成功 |
| SQ-04 | P1 | 跨 Workspace Leader | 选择外部 Agent | 拒绝 |
| SQ-05 | P1 | 无调用权限 Leader | 普通成员选择不可调用私有 Agent | 拒绝 |
| SQ-06 | P1 | Archived Squad | 向 Archived Squad 提交任务 | 拒绝 |
| SQ-07 | P2 | Member Status | Member 有 Running Task | Squad 页显示 Working |

## 6. Lightweight Issue

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| IS-01 | P0 | 创建 Squad Issue | Title/Description/Squad | 创建成功 |
| IS-02 | P0 | 自动触发 Leader | Issue status=`todo` | 创建 Leader Task |
| IS-03 | P1 | Backlog | 创建为 backlog | 不立即触发 |
| IS-04 | P1 | Backlog→Todo | 更新状态 | 触发 Leader |
| IS-05 | P1 | 非法 Assignee | Squad 不存在/Archived | 拒绝 |
| IS-06 | P1 | 状态闭环 | Leader 设置 in_review | 状态正确 |
| IS-07 | P1 | Task Complete 非 Issue Done | Leader 首轮仅委派 | Issue 保持 in_progress |

## 7. Comment 与 Mention

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| CM-01 | P0 | 添加普通 Comment | 用户添加补充 | Timeline 出现 |
| CM-02 | P0 | Agent Mention | Leader 发布 `mention://agent` | 创建目标 Member Task |
| CM-03 | P0 | Squad Mention | 发布 `mention://squad` | 只触发目标 Squad Leader |
| CM-04 | P1 | Plain @name | 只写普通文本 | 不触发 |
| CM-05 | P1 | 重复 Mention | 重复提交同一触发 | 不创建重复 Active Task |
| CM-06 | P1 | 跨 Workspace Mention | Mention 外部 Agent | 拒绝 |
| CM-07 | P1 | Leader Self-trigger | Leader 发布委派 Comment | 不重新触发自己 |
| CM-08 | P1 | source_task_id | Member Task 写结果 | Comment 关联正确 Task |
| CM-09 | P1 | Workspace Integrity | Issue/Workspace 不匹配 | Comment 创建失败 |

## 8. Leader—Member—Leader 核心闭环

| ID | 级别 | 场景 | 步骤 | 预期 |
|---|---|---|---|---|
| FLOW-01 | P0 | 单成员委派 | 用户→Leader→Member→Leader | Leader 能最终进入 in_review |
| FLOW-02 | P0 | 两阶段委派 | Leader→Backend→Leader→Test→Leader | 顺序闭环完整 |
| FLOW-03 | P1 | 多成员并行 | Leader 同时 Mention A/B | 两个独立 Task，无重复 |
| FLOW-04 | P1 | Member Failure | Member Task Failed | 用户和 Leader可见失败 |
| FLOW-05 | P1 | Leader Runtime Offline | 创建 Issue | Issue/Task 不丢，状态明确 |
| FLOW-06 | P1 | 无合适成员 | Leader 无法委派 | 写明能力缺口，不静默执行 |
| FLOW-07 | P1 | Human 补充 | Member 执行中用户补充 | 补充不丢失，后续可重入 |

## 9. Comment Reconciliation

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| RC-01 | P1 | Running 中用户 Comment | Agent 已 Running 时新增 | Task 完成后创建必要 Follow-up |
| RC-02 | P1 | Running 中显式 Agent Mention | 目标已有 Running Task | 不丢 Mention，完成后补偿 |
| RC-03 | P1 | 自己的结果 Comment | Agent 完成时写 Comment | 不错误触发自己 |
| RC-04 | P1 | 多条新 Comment | Running 中连续新增 | 按顺序或合并处理，无永久遗漏 |

## 10. Task Queue

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| TQ-01 | P0 | 单次 Claim | 两个 Daemon 并发 Claim | 只有一个成功 |
| TQ-02 | P1 | WS Claim 结果不确定 | WS 发送后断线 | 不立即 HTTP 双重 Claim |
| TQ-03 | P1 | Complete 幂等 | 重复 Complete | 不重复写结果 |
| TQ-04 | P1 | Fail 幂等 | 重复 Fail | 不重复重试/Comment |
| TQ-05 | P1 | Retry | 可重试 Infra Error | 创建有限次重试 |
| TQ-06 | P1 | Cancel | Running Task Cancel | Runtime 停止并回报 |
| TQ-07 | P1 | Session Pin | Runtime 创建 Session | Server/Chat/Issue 指针更新 |
| TQ-08 | P1 | Orphan Recovery | Daemon 异常退出 | Task 可恢复或失败收敛 |

## 11. 权限与安全

| ID | 级别 | 场景 | 预期 |
|---|---|---|---|
| SEC-01 | P0 | Daemon Token 访问外部 Workspace | 拒绝 |
| SEC-02 | P0 | Task Token 操作无关 Issue | 拒绝 |
| SEC-03 | P1 | Leader 通过 Squad 绕过私有 Agent 权限 | 拒绝 |
| SEC-04 | P1 | Custom Env 普通 GET | 不返回明文 |
| SEC-05 | P1 | MCP Secret 跨用户读取 | 脱敏或拒绝 |
| SEC-06 | P1 | Comment Actor 伪造 | Server 使用可信 Actor Context |

## 12. 删除能力验收

以下页面、路由和导航不得出现在目标版本：

- Issue Board；
- Issue Table；
- Issue Properties；
- Labels；
- Subscribers；
- Reactions；
- Due/Start Date；
- Calendar；
- Child Issue UI；
- Autopilot；
- Slack；
- Feishu；
- Mobile；
- Billing；
- Inbox；
- External Webhook 管理。

## 13. 发布门槛

发布前必须全部通过：

- 所有 P0；
- 所有安全类 P1；
- FLOW-01、FLOW-02；
- CM-07；
- RC-01、RC-02；
- TQ-01、TQ-03、TQ-04；
- 无跨 Workspace 数据泄露；
- 无 Leader 自触发无限循环；
- 无运行期间 Comment 永久丢失。
