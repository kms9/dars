# Multica API 裁剪规范

## 1. 目标

API 只服务于：

- Workspace/Auth；
- Daemon/Runtime；
- Agent；
- Direct Chat；
- Squad；
- Lightweight Issue；
- Lightweight Comment；
- Task Execution；
- Realtime。

## 2. Agent API

### 保留

```http
GET    /api/agents
POST   /api/agents
GET    /api/agents/{agentId}
PATCH  /api/agents/{agentId}
DELETE /api/agents/{agentId}
POST   /api/agents/{agentId}/restore
GET    /api/agents/{agentId}/env
PUT    /api/agents/{agentId}/env
```

### Create Agent 必填

```json
{
  "name": "Backend Agent",
  "description": "...",
  "instructions": "...",
  "runtime_id": "<uuid>"
}
```

### 核心校验

- `runtime_id` 必填；
- Runtime 必须属于当前 Workspace；
- Agent Archived 时不得执行；
- Agent 未绑定 Runtime 时不得执行；
- 调用必须通过 Invocation Permission Gate。

## 3. Runtime/Daemon API

保留：

```text
daemon register
daemon heartbeat
daemon websocket
runtime list
runtime profile CRUD
runtime models/capabilities
task claim
task start
task progress
task messages
task usage
task complete
task fail
task cancel acknowledgement
task session pin
runtime orphan recovery
daemon health/config
```

## 4. Chat API

### 保留

```http
POST   /api/chat/sessions
GET    /api/chat/sessions
GET    /api/chat/sessions/{sessionId}
PATCH  /api/chat/sessions/{sessionId}
DELETE /api/chat/sessions/{sessionId}

GET    /api/chat/sessions/{sessionId}/messages
POST   /api/chat/sessions/{sessionId}/messages
POST   /api/chat/sessions/{sessionId}/cancel
```

### Create Session

```json
{
  "agent_id": "<uuid>",
  "title": "New chat"
}
```

`project_id` 不属于最小核心，可停止暴露。

### Send Message

```json
{
  "content": "..."
}
```

附件为可选保留项，不属于最小运行硬依赖。

## 5. Squad API

### 保留

```http
GET    /api/squads
POST   /api/squads
GET    /api/squads/{squadId}
PATCH  /api/squads/{squadId}
DELETE /api/squads/{squadId}
POST   /api/squads/{squadId}/restore

GET    /api/squads/{squadId}/members
POST   /api/squads/{squadId}/members
DELETE /api/squads/{squadId}/members
PATCH  /api/squads/{squadId}/members/role
GET    /api/squads/{squadId}/member-status
```

### Create Squad

```json
{
  "name": "Feature Squad",
  "description": "...",
  "leader_id": "<agent-uuid>",
  "instructions": "..."
}
```

### Add Member

```json
{
  "member_type": "agent",
  "member_id": "<uuid>",
  "role": "Backend engineer"
}
```

## 6. Lightweight Issue API

### 保留

```http
POST   /api/issues
GET    /api/issues/{issueId}
PATCH  /api/issues/{issueId}
PATCH  /api/issues/{issueId}/status
GET    /api/issues/{issueId}/tasks
```

### Create Issue

```json
{
  "title": "实现用户认证",
  "description": "目标、约束、验收要求",
  "assignee_type": "squad",
  "assignee_id": "<squad-uuid>",
  "status": "todo"
}
```

### Update Issue

只允许：

```json
{
  "title": "...",
  "description": "...",
  "assignee_type": "squad",
  "assignee_id": "<uuid>",
  "status": "in_progress"
}
```

### 删除或停用

```text
/api/issues/table/**
/api/issues/grouped
/api/issues/search
/api/issues/children
/api/issues/child-progress
/api/issues/properties
/api/issues/labels
/api/issues/subscribers
/api/issues/reactions
/api/issues/quick-actions
```

## 7. Lightweight Comment API

### 保留

```http
GET  /api/issues/{issueId}/comments
POST /api/issues/{issueId}/comments
GET  /api/comments/{commentId}
```

### Add Comment

```json
{
  "content": "[@Backend Agent](mention://agent/<uuid>) 实现后端接口。",
  "type": "message"
}
```

可信字段由服务端 Actor Context 决定：

- `author_type`
- `author_id`
- `source_task_id`
- `workspace_id`

客户端不得伪造。

### 删除或停用

```text
comment resolve/unresolve
comment reactions
comment thread page
comment root list
comment quick actions
comment search
comment draft
```

## 8. Squad Activity API

兼容保留：

```http
POST /api/issues/{issueId}/squad-evaluated
```

请求：

```json
{
  "outcome": "action",
  "reason": "delegated backend implementation"
}
```

允许值：

- `action`
- `no_action`
- `failed`

## 9. Task User API

保留：

```http
GET  /api/tasks/{taskId}
GET  /api/tasks/{taskId}/messages
POST /api/tasks/{taskId}/cancel
GET  /api/issues/{issueId}/tasks
```

## 10. 错误码原则

| 场景 | HTTP |
|---|---:|
| 参数错误 | 400 |
| 未认证 | 401 |
| 无调用权限 | 403 |
| 对象不存在或跨 Workspace | 404 |
| Agent Archived/Runtime Missing | 409 |
| 重复或状态冲突 | 409 |
| Runtime 暂不可用 | 503 |
| 服务端错误 | 500 |

## 11. 幂等要求

以下接口或流程必须幂等或防重：

- Task Claim；
- Task Complete；
- Task Fail；
- Task Cancel；
- Comment Mention Enqueue；
- Assigned Squad Leader Trigger；
- Running-task Comment Reconciliation；
- Squad Activity 记录。
