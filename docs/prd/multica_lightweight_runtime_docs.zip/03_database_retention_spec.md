# Multica 数据库字段保留规范

## 1. 原则

本阶段以“停止使用非核心字段”为主，不要求立即 Drop Column 或重写历史 Migration。

字段分为：

- 必须保留；
- 兼容保留；
- 停止写入；
- 最终可删除。

## 2. `workspace`

必须保留：

- `id`
- `slug/name`
- `context/settings`
- `created_at`
- `updated_at`

## 3. `agent_runtime`

必须保留：

- `id`
- `workspace_id`
- `daemon_id`
- `name`
- `type/provider`
- `version`
- `status`
- `profile_id`
- `device_name/custom_name`
- `last_heartbeat_at`
- `created_at`
- `updated_at`

## 4. `agent`

必须保留：

- `id`
- `workspace_id`
- `runtime_id`
- `name`
- `description`
- `instructions`
- `runtime_mode`
- `runtime_config`
- `model`
- `thinking_level`
- `service_tier`
- `custom_args`
- `custom_env`
- `mcp_config`
- `max_concurrent_tasks`
- `permission_mode`
- `owner_id`
- `status`
- `archived_at`
- `archived_by`
- `created_at`
- `updated_at`

## 5. `squad`

必须保留：

- `id`
- `workspace_id`
- `name`
- `description`
- `instructions`
- `leader_id`
- `creator_id`
- `avatar_url`
- `archived_at`
- `archived_by`
- `created_at`
- `updated_at`

## 6. `squad_member`

必须保留：

- `id`
- `squad_id`
- `member_type`
- `member_id`
- `role`
- `created_at`

## 7. `issue`

### 必须保留

| 字段 | 用途 |
|---|---|
| `id` | Squad Run 根 ID |
| `workspace_id` | 租户隔离 |
| `title` | 任务标题 |
| `description` | 目标、约束、验收 |
| `status` | 整体协作状态 |
| `assignee_type` | Agent/Squad |
| `assignee_id` | 实际负责人 |
| `creator_type` | Member/Agent |
| `creator_id` | 发起者 |
| `number` | CLI/页面可读 ID |
| `created_at` | Timeline |
| `updated_at` | 活跃、排序、GC |

### 兼容保留

| 字段 | 处理 |
|---|---|
| `priority` | 固定默认值 |
| `parent_issue_id` | NULL |
| `project_id` | NULL |
| `stage` | NULL |
| `metadata` | `{}` |
| `origin_type` | NULL |
| `origin_id` | NULL |
| `position` | 默认值 |
| `start_date` | NULL |
| `due_date` | NULL |
| `properties` | `{}` |

### 最终可删除

- `position`
- `start_date`
- `due_date`
- `project_id`
- `stage`
- `properties`
- `origin_type`
- `origin_id`
- 项目管理 Metadata

## 8. `comment`

### 必须保留

| 字段 | 用途 |
|---|---|
| `id` | Comment/Event ID |
| `issue_id` | 所属 Squad Run |
| `workspace_id` | 租户隔离 |
| `author_type` | member/agent/system |
| `author_id` | 作者和防自触发 |
| `content` | 命令、结果、补充 |
| `type` | 消息类型 |
| `source_task_id` | 结果来源 |
| `created_at` | 顺序和增量 |
| `updated_at` | 编辑时间 |

### 兼容保留但不使用

- `parent_id = NULL`
- `quick_action_id = NULL`
- `resolved_at = NULL`
- `resolved_by_type = NULL`
- `resolved_by_id = NULL`

### 最终可删除

- Thread 相关字段和索引；
- Resolution 字段；
- Quick Action 字段；
- Reaction 关联表。

## 9. `chat_session`

必须保留：

- `id`
- `workspace_id`
- `agent_id`
- `creator_id`
- `title`
- `session_id`
- `work_dir`
- `runtime_id`
- `status`
- `pinned_at`
- `last_read_at`
- `created_at`
- `updated_at`

可停用：

- `project_id`
- External Channel Binding；
- 非必要 Agent Intro 字段。

## 10. `chat_message`

必须保留：

- `id`
- `chat_session_id`
- `role`
- `content`
- `task_id`
- `failure_reason`
- `elapsed_ms`
- `message_kind`
- `created_at`

可停用：

- `quick_actions`
- Channel Media；
- Channel Ingested；
- 外部渠道专用字段。

## 11. `agent_task_queue`

必须保留：

- `id`
- `agent_id`
- `runtime_id`
- `issue_id`
- `chat_session_id`
- `squad_id`
- `is_leader_task`
- `status`
- `priority`
- `attempt`
- `max_attempts`
- `parent_task_id`
- `session_id`
- `work_dir`
- `result`
- `error`
- `failure_reason`
- `usage`
- `runtime_mcp_overlay`
- `initiator_user_id`
- `originator_user_id`
- `accountable_user_id`
- `trigger_comment_id`
- `created_at`
- `dispatched_at`
- `started_at`
- `completed_at`

停止使用：

- `autopilot_run_id`
- Quick Create Context；
- External Channel 专用上下文；
- Child Stage 专用字段。

## 12. `activity_log`

最小保留：

- `workspace_id`
- `issue_id`
- `actor_type`
- `actor_id`
- `action = squad_leader_evaluated`
- `details`
- `created_at`

## 13. 可删除表

解耦完成后可以删除：

- Issue Properties；
- Labels；
- Subscribers；
- Reactions；
- Autopilot；
- Autopilot Run；
- Channel Installation/Binding；
- Inbox/Notification；
- Billing；
- VCS Issue Link；
- Child Stage 专用表；
- Quick Actions。

## 14. 关键约束

必须保证：

```text
comment.workspace_id == issue.workspace_id
task.runtime_id belongs to task workspace
agent.runtime_id belongs to agent workspace
squad.leader_id belongs to squad workspace
mention target belongs to issue workspace
```

## 15. 关键索引

```sql
issue(workspace_id, updated_at)
issue(workspace_id, status)
comment(issue_id, created_at, id)
comment(workspace_id, issue_id)
agent_task_queue(runtime_id, status, created_at)
agent_task_queue(issue_id, agent_id, status)
agent_task_queue(chat_session_id, status)
agent_runtime(workspace_id, daemon_id)
squad(workspace_id)
squad_member(squad_id)
chat_session(workspace_id, creator_id, updated_at)
chat_message(chat_session_id, created_at)
```
