# Multica 轻量智能体与小队协作运行时文档合集

本合集包括产品需求、代码范围、API、数据库和端到端验收文档。


---

# Multica 轻量智能体与小队协作运行时需求文档

> 基础仓库：`kms9/multica`  
> 基准提交：`736fbc8a5f1b22d48354a0e55baa00661e9e4326`  
> 文档目标：保留本地 Daemon、Runtime、Agent、Direct Chat、Squad 与最小 Issue/Comment 协作闭环，删除完整项目管理外围能力。

## 1. 核心结论

目标系统不是完整的项目管理产品，而是：

```text
Workspace
├── Desktop / Web
├── Local Daemon
├── Runtime
├── Agent
├── Direct Chat
├── Squad
├── Lightweight Issue
├── Flat Comment Timeline
└── Durable Task Queue
```

其中：

- `Issue` 是一次 Agent/Squad 协作运行的持久化根对象；
- `Comment` 是委派、结果、补充信息和重入触发事件；
- `Task Queue` 是单次 Agent 调用的可靠执行记录；
- `Squad` 是 Leader、成员、角色、Skills 和 Instructions 的静态组织定义；
- `Daemon` 是本地 Runtime 的执行宿主。

## 2. 产品目标

1. 用户可以通过 Desktop 启动并配对本地 Daemon。
2. Daemon 可以发现、注册和维护本地 Runtime。
3. 用户可以选择 Runtime 创建 Agent。
4. 用户可以和单个 Agent Direct Chat。
5. 用户可以创建 Squad，设置 Leader、成员、Role 和 Instructions。
6. 用户可以向 Squad 提交一项工作。
7. Leader 可以通过 Comment Mention 委派成员。
8. Member 可以执行任务并写回结果 Comment。
9. Member Comment 可以重新唤醒 Leader。
10. Leader 可以继续委派、要求修正或将整体工作推进到 Review。
11. 系统删除 Issue Board、Table、Properties、Labels、Subscribers、Reactions、Autopilot 和外部渠道等外围能力。

## 3. 非目标

本阶段不包含：

- 新建独立 `SquadRun` 数据模型；
- 新建 DAG、BPMN、Temporal 或自动 fan-out/fan-in 引擎；
- 将 Chat Session 立即改造成多 Agent 协作会话；
- 重新设计 Squad 调度协议；
- 保留完整 Linear/Jira 类项目管理能力；
- 立即物理删除所有历史字段和 Migration。

## 4. 核心对象

### 4.1 Workspace

Workspace 是用户、Daemon、Runtime、Agent、Squad、Issue、Comment、Chat Session 和 Task 的隔离边界。

### 4.2 Runtime

Runtime 表示实际执行 Agent 的提供者实例，例如 Codex、Claude Code、OpenCode、Cursor、OpenClaw 或自定义 Runtime Profile。

### 4.3 Agent

Agent 至少保留：

- `name`
- `description`
- `instructions`
- `runtime_id`
- `runtime_mode`
- `model`
- `thinking_level`
- `service_tier`
- `skills`
- `mcp_config`
- `runtime_config`
- `custom_args`
- `custom_env`
- `max_concurrent_tasks`
- `permission_mode`

### 4.4 Squad

Squad 至少保留：

- `name`
- `description`
- `leader_id`
- `instructions`
- Agent/Human Members
- Member Role
- Archive 状态

Squad 本身不是可执行进程。所有 Squad 工作先路由到 Leader，再由 Leader 通过 Comment Mention 派发成员。

### 4.5 Lightweight Issue

Issue 负责：

- 总目标；
- 描述和验收要求；
- 当前 Assignee；
- 整体状态；
- Comments；
- Agent Tasks；
- 发起者和归因。

### 4.6 Lightweight Comment

Comment 负责：

- 用户补充；
- Leader 委派；
- Member 结果；
- Leader 判断；
- Mention 触发；
- Leader 重入；
- 运行期间新消息补偿。

### 4.7 Agent Task

Agent Task 负责单次执行状态：

```text
queued → dispatched → running → completed/failed/cancelled
```

必须保证：

```text
Task completed != Issue completed
```

Leader 的一次 Task 可能只完成了成员委派。

## 5. 核心流程

### 5.1 Direct Chat

```text
User Message
→ chat_message
→ Chat Task
→ Daemon Claim
→ Runtime Execute
→ Streaming
→ Assistant Message
```

Direct Chat 不依赖 Issue。

### 5.2 Squad Run

```text
Create Issue assigned to Squad
→ Enqueue Leader Task
→ Leader reads Issue + Comments + Squad Briefing
→ Leader posts Comment with @Member mention
→ Enqueue Member Task
→ Member executes and posts result Comment
→ Re-trigger Leader
→ Leader continues or sets Issue in_review
```

## 6. 状态模型

建议后端继续保留：

```text
backlog
todo
in_progress
in_review
done
cancelled
```

最小 UI 可以只突出：

```text
Active / Review / Done / Cancelled
```

## 7. 必须保留的可靠性能力

- Mention Parser；
- Assigned Squad Leader Trigger；
- Leader Self-trigger Guard；
- Pending Task Dedup；
- Comment Reconciliation；
- Workspace Tenant Guard；
- Task Complete/Fail 幂等；
- Result Comment/Fallback Comment；
- Session/WorkDir Resume；
- Runtime Offline 处理；
- Task Retry；
- Realtime Task/Comment/Issue Events。

## 8. 页面范围

保留：

- Desktop Daemon；
- Runtime；
- Agent List/Create/Detail；
- Direct Chat；
- Squad List/Create/Detail；
- 轻量任务创建；
- 轻量 Squad Run Detail。

删除：

- Issue Board；
- Issue Table；
- Issue Properties；
- Labels；
- Subscribers；
- Reactions；
- Calendar；
- Complex Search；
- Child Issue Tree；
- Autopilot；
- Slack/Feishu；
- Mobile；
- Billing；
- Inbox。

## 9. 最终验收主流程

1. Desktop 启动 Daemon。
2. Daemon 注册本地 Runtime。
3. 用户选择 Runtime 创建 Leader、Backend Agent 和 Test Agent。
4. 用户创建 Squad。
5. 用户提交 Issue 给 Squad。
6. Leader 被触发并 Mention Backend Agent。
7. Backend Agent 完成并写结果 Comment。
8. Leader 被重新触发并 Mention Test Agent。
9. Test Agent 完成并写验证 Comment。
10. Leader 再次被触发并将 Issue 置为 `in_review`。
11. 用户能看到完整 Timeline、Tasks、Runtime 和最终结果。


---

# Multica 代码保留、裁剪与删除清单

> 基准提交：`736fbc8a5f1b22d48354a0e55baa00661e9e4326`

## 1. 分类定义

| 分类 | 含义 |
|---|---|
| 保留 | 目标系统运行的硬依赖 |
| 裁剪 | 文件或模块保留，但删除非核心分支 |
| 停用 | 路由/UI 不再暴露，代码可暂时存在 |
| 删除 | 解耦完成后可以从目标代码库移除 |

## 2. Desktop

### 保留

```text
apps/desktop/src/main/**
apps/desktop/src/preload/**
apps/desktop/src/renderer/**
apps/desktop/electron.vite.config.*
apps/desktop/package.json
```

必须保留：

- Electron Main/Preload/Renderer；
- Token Sync；
- Daemon Auto Start；
- Daemon Start/Stop/Restart；
- Health Check；
- CLI 发现、下载和升级；
- Desktop Profile；
- Daemon 日志；
- IPC API。

### 裁剪

- 删除 Issue Board、Inbox、Billing、External Integration 入口；
- Renderer 只挂载目标 Web Views。

## 3. Daemon 与 Runtime

### 保留

```text
server/internal/daemon/**
server/internal/daemonws/**
server/internal/handler/daemon.go
server/internal/handler/daemon_ws.go
server/pkg/agent/**
server/pkg/protocol/**
server/cmd/multica/
```

保留 Register、Heartbeat、Discovery、Runtime Profile、Claim、Start、Progress、Messages、Usage、Complete、Fail、Cancel、Session、WorkDir、Orphan Recovery 和 WS Wakeup。

### 删除候选

若仅支持本地 Runtime：

```text
server/internal/cloudruntime/**
Cloud Fleet/Gateway
Cloud Runtime 购买和配置 UI
```

## 4. Agent

### 保留

```text
server/internal/handler/agent.go
server/internal/handler/agent_access.go
server/pkg/db/queries/agent.sql
Agent Skills
Runtime Profile
Agent Env/MCP/Config
```

保留 Create/Get/List/Update/Archive/Restore、Runtime 绑定、Model、Skills、MCP、Env、Invocation Permission 和 Runtime Required Gate。

## 5. Direct Chat

### 保留

```text
server/internal/handler/chat.go
server/pkg/db/queries/chat.sql
Chat Realtime Events
TaskService Chat 分支
packages/views/chat/**
packages/core/chat/**
```

### 裁剪

可停用：

- Project Context；
- Chat Quick Actions；
- External Channel Binding；
- Channel Media；
- 非必要 Agent Intro。

## 6. Squad

### 保留

```text
server/internal/handler/squad.go
server/internal/handler/squad_briefing.go
server/pkg/db/queries/squad.sql
server/internal/service/builtin_skills/multica-squads/**
server/cmd/multica/cmd_squad.go
packages/views/squads/**
```

保留 Squad CRUD、Leader、Members、Role、Instructions、Roster、Skills、Leader Briefing、Leader Routing、Readiness、Dedup、Self-trigger Guard 和 Squad Activity。

### 裁剪

删除或隔离：

- Active Issues 展示；
- Issue 统计；
- Archive 时转移 Issue Assignee；
- Autopilot Assignee Transfer；
- Child Issue/Stage；
- 通用 Activity Feed。

## 7. Lightweight Issue

### 保留或拆出 Core

```text
server/internal/handler/issue.go
server/internal/handler/issue_trigger.go
server/pkg/db/queries/issue.sql
server/cmd/multica/cmd_issue.go
```

仅保留：

- Create；
- Get；
- Update Title/Description；
- Update Assignee；
- Update Status；
- Squad Assignment Trigger；
- List Tasks；
- Workspace Guard；
- Assignee Validation。

### 删除

```text
server/internal/handler/issue_table_*.go
Issue Board/Table/Group/Facet
Properties
Labels
Subscribers
Reactions
Due/Start Date
Calendar
Complex Search
Bulk Actions
Assignee Frequency
VCS Issue Link
Child Progress
```

## 8. Lightweight Comment

### 保留

```text
server/internal/handler/comment.go
server/pkg/db/queries/comment.sql
Mention Parser
Comment Trigger Pipeline
Comment Reconciliation
```

仅保留 Add、Flat List、Get、Mention Trigger、Assigned Squad Leader Trigger、Self-trigger Guard、Dedup、Reconciliation、Workspace Integrity 和 `source_task_id`。

### 删除

- Nested Thread；
- Root Thread；
- Thread Pagination；
- Resolve/Unresolve；
- Reactions；
- Quick Actions；
- Draft；
- Thread Ranking；
- Comment Search。

## 9. TaskService

`server/internal/service/task.go` 不应整体删除。

### 必须保留

- Chat Task；
- Issue Task；
- Squad Leader Task；
- Mention Member Task；
- Claim/Start/Messages/Complete/Fail/Cancel/Retry；
- Session/WorkDir；
- Usage；
- Realtime；
- Workspace Resolution；
- Comment Reconciliation；
- Result Delivery。

### 删除分支

- Autopilot；
- Quick Create；
- External Channel；
- Child Done；
- 项目管理 Analytics；
- Thread/Quick Action 相关分支。

### 推荐边界

```text
task_core.go
task_claim.go
task_chat.go
task_issue_core.go
task_comment_trigger.go
task_squad.go
task_retry.go
task_realtime.go
```

## 10. Router

### 保留

- Auth/Workspace；
- Daemon/Runtime；
- Agent；
- Chat；
- Squad；
- Lightweight Issue；
- Lightweight Comment；
- Task；
- Realtime。

### 删除

- Issue Table/Facet/Group；
- Properties；
- Labels；
- Subscribers；
- Reactions；
- Quick Actions；
- Autopilot；
- Channels；
- Lark；
- Slack；
- Billing；
- Inbox；
- External Webhooks。

## 11. Frontend

### 保留

```text
packages/views/agents/**
packages/views/chat/**
packages/views/squads/**
packages/core/agents/**
packages/core/chat/**
packages/core/api/**
packages/core/realtime/**
packages/ui/**
```

### 裁剪保留

`packages/views/issues/**` 与 `packages/core/issues/**` 仅保留：

- Lightweight Run Create；
- Lightweight Run Detail；
- Flat Comment Timeline；
- Comment Composer；
- Task Execution List；
- Status；
- Assignee Squad。

### 共享组件迁出

- Picker；
- Agent Permission Helper；
- Timeline Row；
- Task Status Pill；
- Markdown/Avatar。

目标位置：

```text
packages/ui/**
packages/views/common/**
packages/core/agents/**
```

## 12. 整体删除

```text
apps/mobile/**
Autopilot
Slack
Lark/Feishu
Channel Engine
Billing/Stripe
Inbox
Notifications
Issue Board/Table
Properties
Labels
Subscribers
Reactions
External Webhooks
Complex Analytics
```

## 13. 保留判定

模块只有满足以下至少一项才保留：

1. Daemon/Runtime 配对；
2. Agent 创建或执行；
3. Direct Chat；
4. Leader—Member—Leader 闭环；
5. Workspace 安全隔离；
6. Task 可靠执行和恢复；
7. 目标页面直接依赖。


---

# Multica API 裁剪规范

## 1. 目标

API 只服务于：

- Workspace/Auth；
- Daemon/Runtime；
- Agent；
- Direct Chat；
- Squad；
- Lightweight Issue；
- Lightweight Comment；
- Task Execution；
- Realtime。

## 2. Agent API

### 保留

```http
GET    /api/agents
POST   /api/agents
GET    /api/agents/{agentId}
PATCH  /api/agents/{agentId}
DELETE /api/agents/{agentId}
POST   /api/agents/{agentId}/restore
GET    /api/agents/{agentId}/env
PUT    /api/agents/{agentId}/env
```

### Create Agent 必填

```json
{
  "name": "Backend Agent",
  "description": "...",
  "instructions": "...",
  "runtime_id": "<uuid>"
}
```

### 核心校验

- `runtime_id` 必填；
- Runtime 必须属于当前 Workspace；
- Agent Archived 时不得执行；
- Agent 未绑定 Runtime 时不得执行；
- 调用必须通过 Invocation Permission Gate。

## 3. Runtime/Daemon API

保留：

```text
daemon register
daemon heartbeat
daemon websocket
runtime list
runtime profile CRUD
runtime models/capabilities
task claim
task start
task progress
task messages
task usage
task complete
task fail
task cancel acknowledgement
task session pin
runtime orphan recovery
daemon health/config
```

## 4. Chat API

### 保留

```http
POST   /api/chat/sessions
GET    /api/chat/sessions
GET    /api/chat/sessions/{sessionId}
PATCH  /api/chat/sessions/{sessionId}
DELETE /api/chat/sessions/{sessionId}

GET    /api/chat/sessions/{sessionId}/messages
POST   /api/chat/sessions/{sessionId}/messages
POST   /api/chat/sessions/{sessionId}/cancel
```

### Create Session

```json
{
  "agent_id": "<uuid>",
  "title": "New chat"
}
```

`project_id` 不属于最小核心，可停止暴露。

### Send Message

```json
{
  "content": "..."
}
```

附件为可选保留项，不属于最小运行硬依赖。

## 5. Squad API

### 保留

```http
GET    /api/squads
POST   /api/squads
GET    /api/squads/{squadId}
PATCH  /api/squads/{squadId}
DELETE /api/squads/{squadId}
POST   /api/squads/{squadId}/restore

GET    /api/squads/{squadId}/members
POST   /api/squads/{squadId}/members
DELETE /api/squads/{squadId}/members
PATCH  /api/squads/{squadId}/members/role
GET    /api/squads/{squadId}/member-status
```

### Create Squad

```json
{
  "name": "Feature Squad",
  "description": "...",
  "leader_id": "<agent-uuid>",
  "instructions": "..."
}
```

### Add Member

```json
{
  "member_type": "agent",
  "member_id": "<uuid>",
  "role": "Backend engineer"
}
```

## 6. Lightweight Issue API

### 保留

```http
POST   /api/issues
GET    /api/issues/{issueId}
PATCH  /api/issues/{issueId}
PATCH  /api/issues/{issueId}/status
GET    /api/issues/{issueId}/tasks
```

### Create Issue

```json
{
  "title": "实现用户认证",
  "description": "目标、约束、验收要求",
  "assignee_type": "squad",
  "assignee_id": "<squad-uuid>",
  "status": "todo"
}
```

### Update Issue

只允许：

```json
{
  "title": "...",
  "description": "...",
  "assignee_type": "squad",
  "assignee_id": "<uuid>",
  "status": "in_progress"
}
```

### 删除或停用

```text
/api/issues/table/**
/api/issues/grouped
/api/issues/search
/api/issues/children
/api/issues/child-progress
/api/issues/properties
/api/issues/labels
/api/issues/subscribers
/api/issues/reactions
/api/issues/quick-actions
```

## 7. Lightweight Comment API

### 保留

```http
GET  /api/issues/{issueId}/comments
POST /api/issues/{issueId}/comments
GET  /api/comments/{commentId}
```

### Add Comment

```json
{
  "content": "[@Backend Agent](mention://agent/<uuid>) 实现后端接口。",
  "type": "message"
}
```

可信字段由服务端 Actor Context 决定：

- `author_type`
- `author_id`
- `source_task_id`
- `workspace_id`

客户端不得伪造。

### 删除或停用

```text
comment resolve/unresolve
comment reactions
comment thread page
comment root list
comment quick actions
comment search
comment draft
```

## 8. Squad Activity API

兼容保留：

```http
POST /api/issues/{issueId}/squad-evaluated
```

请求：

```json
{
  "outcome": "action",
  "reason": "delegated backend implementation"
}
```

允许值：

- `action`
- `no_action`
- `failed`

## 9. Task User API

保留：

```http
GET  /api/tasks/{taskId}
GET  /api/tasks/{taskId}/messages
POST /api/tasks/{taskId}/cancel
GET  /api/issues/{issueId}/tasks
```

## 10. 错误码原则

| 场景 | HTTP |
|---|---:|
| 参数错误 | 400 |
| 未认证 | 401 |
| 无调用权限 | 403 |
| 对象不存在或跨 Workspace | 404 |
| Agent Archived/Runtime Missing | 409 |
| 重复或状态冲突 | 409 |
| Runtime 暂不可用 | 503 |
| 服务端错误 | 500 |

## 11. 幂等要求

以下接口或流程必须幂等或防重：

- Task Claim；
- Task Complete；
- Task Fail；
- Task Cancel；
- Comment Mention Enqueue；
- Assigned Squad Leader Trigger；
- Running-task Comment Reconciliation；
- Squad Activity 记录。


---

# Multica 数据库字段保留规范

## 1. 原则

本阶段以“停止使用非核心字段”为主，不要求立即 Drop Column 或重写历史 Migration。

字段分为：

- 必须保留；
- 兼容保留；
- 停止写入；
- 最终可删除。

## 2. `workspace`

必须保留：

- `id`
- `slug/name`
- `context/settings`
- `created_at`
- `updated_at`

## 3. `agent_runtime`

必须保留：

- `id`
- `workspace_id`
- `daemon_id`
- `name`
- `type/provider`
- `version`
- `status`
- `profile_id`
- `device_name/custom_name`
- `last_heartbeat_at`
- `created_at`
- `updated_at`

## 4. `agent`

必须保留：

- `id`
- `workspace_id`
- `runtime_id`
- `name`
- `description`
- `instructions`
- `runtime_mode`
- `runtime_config`
- `model`
- `thinking_level`
- `service_tier`
- `custom_args`
- `custom_env`
- `mcp_config`
- `max_concurrent_tasks`
- `permission_mode`
- `owner_id`
- `status`
- `archived_at`
- `archived_by`
- `created_at`
- `updated_at`

## 5. `squad`

必须保留：

- `id`
- `workspace_id`
- `name`
- `description`
- `instructions`
- `leader_id`
- `creator_id`
- `avatar_url`
- `archived_at`
- `archived_by`
- `created_at`
- `updated_at`

## 6. `squad_member`

必须保留：

- `id`
- `squad_id`
- `member_type`
- `member_id`
- `role`
- `created_at`

## 7. `issue`

### 必须保留

| 字段 | 用途 |
|---|---|
| `id` | Squad Run 根 ID |
| `workspace_id` | 租户隔离 |
| `title` | 任务标题 |
| `description` | 目标、约束、验收 |
| `status` | 整体协作状态 |
| `assignee_type` | Agent/Squad |
| `assignee_id` | 实际负责人 |
| `creator_type` | Member/Agent |
| `creator_id` | 发起者 |
| `number` | CLI/页面可读 ID |
| `created_at` | Timeline |
| `updated_at` | 活跃、排序、GC |

### 兼容保留

| 字段 | 处理 |
|---|---|
| `priority` | 固定默认值 |
| `parent_issue_id` | NULL |
| `project_id` | NULL |
| `stage` | NULL |
| `metadata` | `{}` |
| `origin_type` | NULL |
| `origin_id` | NULL |
| `position` | 默认值 |
| `start_date` | NULL |
| `due_date` | NULL |
| `properties` | `{}` |

### 最终可删除

- `position`
- `start_date`
- `due_date`
- `project_id`
- `stage`
- `properties`
- `origin_type`
- `origin_id`
- 项目管理 Metadata

## 8. `comment`

### 必须保留

| 字段 | 用途 |
|---|---|
| `id` | Comment/Event ID |
| `issue_id` | 所属 Squad Run |
| `workspace_id` | 租户隔离 |
| `author_type` | member/agent/system |
| `author_id` | 作者和防自触发 |
| `content` | 命令、结果、补充 |
| `type` | 消息类型 |
| `source_task_id` | 结果来源 |
| `created_at` | 顺序和增量 |
| `updated_at` | 编辑时间 |

### 兼容保留但不使用

- `parent_id = NULL`
- `quick_action_id = NULL`
- `resolved_at = NULL`
- `resolved_by_type = NULL`
- `resolved_by_id = NULL`

### 最终可删除

- Thread 相关字段和索引；
- Resolution 字段；
- Quick Action 字段；
- Reaction 关联表。

## 9. `chat_session`

必须保留：

- `id`
- `workspace_id`
- `agent_id`
- `creator_id`
- `title`
- `session_id`
- `work_dir`
- `runtime_id`
- `status`
- `pinned_at`
- `last_read_at`
- `created_at`
- `updated_at`

可停用：

- `project_id`
- External Channel Binding；
- 非必要 Agent Intro 字段。

## 10. `chat_message`

必须保留：

- `id`
- `chat_session_id`
- `role`
- `content`
- `task_id`
- `failure_reason`
- `elapsed_ms`
- `message_kind`
- `created_at`

可停用：

- `quick_actions`
- Channel Media；
- Channel Ingested；
- 外部渠道专用字段。

## 11. `agent_task_queue`

必须保留：

- `id`
- `agent_id`
- `runtime_id`
- `issue_id`
- `chat_session_id`
- `squad_id`
- `is_leader_task`
- `status`
- `priority`
- `attempt`
- `max_attempts`
- `parent_task_id`
- `session_id`
- `work_dir`
- `result`
- `error`
- `failure_reason`
- `usage`
- `runtime_mcp_overlay`
- `initiator_user_id`
- `originator_user_id`
- `accountable_user_id`
- `trigger_comment_id`
- `created_at`
- `dispatched_at`
- `started_at`
- `completed_at`

停止使用：

- `autopilot_run_id`
- Quick Create Context；
- External Channel 专用上下文；
- Child Stage 专用字段。

## 12. `activity_log`

最小保留：

- `workspace_id`
- `issue_id`
- `actor_type`
- `actor_id`
- `action = squad_leader_evaluated`
- `details`
- `created_at`

## 13. 可删除表

解耦完成后可以删除：

- Issue Properties；
- Labels；
- Subscribers；
- Reactions；
- Autopilot；
- Autopilot Run；
- Channel Installation/Binding；
- Inbox/Notification；
- Billing；
- VCS Issue Link；
- Child Stage 专用表；
- Quick Actions。

## 14. 关键约束

必须保证：

```text
comment.workspace_id == issue.workspace_id
task.runtime_id belongs to task workspace
agent.runtime_id belongs to agent workspace
squad.leader_id belongs to squad workspace
mention target belongs to issue workspace
```

## 15. 关键索引

```sql
issue(workspace_id, updated_at)
issue(workspace_id, status)
comment(issue_id, created_at, id)
comment(workspace_id, issue_id)
agent_task_queue(runtime_id, status, created_at)
agent_task_queue(issue_id, agent_id, status)
agent_task_queue(chat_session_id, status)
agent_runtime(workspace_id, daemon_id)
squad(workspace_id)
squad_member(squad_id)
chat_session(workspace_id, creator_id, updated_at)
chat_message(chat_session_id, created_at)
```


---

# Multica 端到端验收用例矩阵

## 1. 验收级别

| 级别 | 含义 |
|---|---|
| P0 | 不通过则目标系统不可运行 |
| P1 | 核心可靠性或安全能力 |
| P2 | 可用性和管理能力 |

## 2. Daemon 与 Runtime

| ID | 级别 | 场景 | 前置条件 | 操作 | 预期 |
|---|---|---|---|---|---|
| DR-01 | P0 | Desktop 启动 Daemon | 用户已登录 | 打开 Desktop | Daemon 自动启动并 Health Ready |
| DR-02 | P0 | Runtime 注册 | 本地安装 Codex/Claude | Daemon 启动 | Server 出现对应 Runtime |
| DR-03 | P1 | Runtime 离线 | Runtime 已注册 | 停止 Daemon | Web 显示 Offline |
| DR-04 | P1 | Runtime 恢复 | Runtime Offline | 重启 Daemon | 原 Runtime 恢复或正确重新注册 |
| DR-05 | P1 | 多 Runtime | 一台设备多个 Provider | 启动 Daemon | Web 按设备展示多个 Runtime |
| DR-06 | P1 | Workspace 隔离 | 两个 Workspace | Daemon 使用 WS-A Token | 不得访问 WS-B Runtime/Task |

## 3. Agent

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| AG-01 | P0 | 创建 Agent | 选择有效 Runtime 创建 | 创建成功且绑定 Runtime |
| AG-02 | P0 | Runtime 必填 | 不选 Runtime 提交 | 400/明确错误 |
| AG-03 | P1 | 跨 Workspace Runtime | 传入其他 Workspace Runtime | 拒绝 |
| AG-04 | P1 | Runtime Offline | 绑定 Offline Runtime 执行 | 明确阻塞或保留队列，不静默丢失 |
| AG-05 | P1 | Archive Agent | 归档后执行 | 拒绝 |
| AG-06 | P1 | 私有 Agent | 非授权用户调用 | 403 |
| AG-07 | P2 | Skills/MCP | 创建并配置 Skills/MCP | Claim Payload 正确包含 |

## 4. Direct Chat

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| CH-01 | P0 | 新建 Chat | 选择 Agent 发送消息 | 创建 Session、Message、Task |
| CH-02 | P0 | Claim Chat Task | Daemon Claim | `issue_id` 为空，`chat_session_id` 有效 |
| CH-03 | P0 | Streaming | Runtime 输出流 | UI 实时展示 |
| CH-04 | P0 | Complete | Runtime 完成 | 创建 Assistant Message |
| CH-05 | P1 | Fail | Runtime 返回错误 | 创建可见 Failure Message |
| CH-06 | P1 | Cancel Queued | 用户取消 | Task Cancelled，输入可恢复 |
| CH-07 | P1 | Cancel Running | 用户取消 | Daemon 收到取消并确认 |
| CH-08 | P1 | Resume | 连续发送两轮 | 使用安全 Session/WorkDir |
| CH-09 | P1 | Runtime Missing | Agent 无 Runtime | 409，禁止执行 |
| CH-10 | P2 | Archive Session | 归档后发送 | 拒绝，历史保留 |

## 5. Squad 配置

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| SQ-01 | P0 | 创建 Squad | 选择 Leader 创建 | Squad 创建成功 |
| SQ-02 | P0 | Leader 自动入组 | 创建 Squad | Leader Member Role=`leader` |
| SQ-03 | P0 | 添加 Agent Member | 添加成员和 Role | 成功 |
| SQ-04 | P1 | 跨 Workspace Leader | 选择外部 Agent | 拒绝 |
| SQ-05 | P1 | 无调用权限 Leader | 普通成员选择不可调用私有 Agent | 拒绝 |
| SQ-06 | P1 | Archived Squad | 向 Archived Squad 提交任务 | 拒绝 |
| SQ-07 | P2 | Member Status | Member 有 Running Task | Squad 页显示 Working |

## 6. Lightweight Issue

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| IS-01 | P0 | 创建 Squad Issue | Title/Description/Squad | 创建成功 |
| IS-02 | P0 | 自动触发 Leader | Issue status=`todo` | 创建 Leader Task |
| IS-03 | P1 | Backlog | 创建为 backlog | 不立即触发 |
| IS-04 | P1 | Backlog→Todo | 更新状态 | 触发 Leader |
| IS-05 | P1 | 非法 Assignee | Squad 不存在/Archived | 拒绝 |
| IS-06 | P1 | 状态闭环 | Leader 设置 in_review | 状态正确 |
| IS-07 | P1 | Task Complete 非 Issue Done | Leader 首轮仅委派 | Issue 保持 in_progress |

## 7. Comment 与 Mention

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| CM-01 | P0 | 添加普通 Comment | 用户添加补充 | Timeline 出现 |
| CM-02 | P0 | Agent Mention | Leader 发布 `mention://agent` | 创建目标 Member Task |
| CM-03 | P0 | Squad Mention | 发布 `mention://squad` | 只触发目标 Squad Leader |
| CM-04 | P1 | Plain @name | 只写普通文本 | 不触发 |
| CM-05 | P1 | 重复 Mention | 重复提交同一触发 | 不创建重复 Active Task |
| CM-06 | P1 | 跨 Workspace Mention | Mention 外部 Agent | 拒绝 |
| CM-07 | P1 | Leader Self-trigger | Leader 发布委派 Comment | 不重新触发自己 |
| CM-08 | P1 | source_task_id | Member Task 写结果 | Comment 关联正确 Task |
| CM-09 | P1 | Workspace Integrity | Issue/Workspace 不匹配 | Comment 创建失败 |

## 8. Leader—Member—Leader 核心闭环

| ID | 级别 | 场景 | 步骤 | 预期 |
|---|---|---|---|---|
| FLOW-01 | P0 | 单成员委派 | 用户→Leader→Member→Leader | Leader 能最终进入 in_review |
| FLOW-02 | P0 | 两阶段委派 | Leader→Backend→Leader→Test→Leader | 顺序闭环完整 |
| FLOW-03 | P1 | 多成员并行 | Leader 同时 Mention A/B | 两个独立 Task，无重复 |
| FLOW-04 | P1 | Member Failure | Member Task Failed | 用户和 Leader可见失败 |
| FLOW-05 | P1 | Leader Runtime Offline | 创建 Issue | Issue/Task 不丢，状态明确 |
| FLOW-06 | P1 | 无合适成员 | Leader 无法委派 | 写明能力缺口，不静默执行 |
| FLOW-07 | P1 | Human 补充 | Member 执行中用户补充 | 补充不丢失，后续可重入 |

## 9. Comment Reconciliation

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| RC-01 | P1 | Running 中用户 Comment | Agent 已 Running 时新增 | Task 完成后创建必要 Follow-up |
| RC-02 | P1 | Running 中显式 Agent Mention | 目标已有 Running Task | 不丢 Mention，完成后补偿 |
| RC-03 | P1 | 自己的结果 Comment | Agent 完成时写 Comment | 不错误触发自己 |
| RC-04 | P1 | 多条新 Comment | Running 中连续新增 | 按顺序或合并处理，无永久遗漏 |

## 10. Task Queue

| ID | 级别 | 场景 | 操作 | 预期 |
|---|---|---|---|---|
| TQ-01 | P0 | 单次 Claim | 两个 Daemon 并发 Claim | 只有一个成功 |
| TQ-02 | P1 | WS Claim 结果不确定 | WS 发送后断线 | 不立即 HTTP 双重 Claim |
| TQ-03 | P1 | Complete 幂等 | 重复 Complete | 不重复写结果 |
| TQ-04 | P1 | Fail 幂等 | 重复 Fail | 不重复重试/Comment |
| TQ-05 | P1 | Retry | 可重试 Infra Error | 创建有限次重试 |
| TQ-06 | P1 | Cancel | Running Task Cancel | Runtime 停止并回报 |
| TQ-07 | P1 | Session Pin | Runtime 创建 Session | Server/Chat/Issue 指针更新 |
| TQ-08 | P1 | Orphan Recovery | Daemon 异常退出 | Task 可恢复或失败收敛 |

## 11. 权限与安全

| ID | 级别 | 场景 | 预期 |
|---|---|---|---|
| SEC-01 | P0 | Daemon Token 访问外部 Workspace | 拒绝 |
| SEC-02 | P0 | Task Token 操作无关 Issue | 拒绝 |
| SEC-03 | P1 | Leader 通过 Squad 绕过私有 Agent 权限 | 拒绝 |
| SEC-04 | P1 | Custom Env 普通 GET | 不返回明文 |
| SEC-05 | P1 | MCP Secret 跨用户读取 | 脱敏或拒绝 |
| SEC-06 | P1 | Comment Actor 伪造 | Server 使用可信 Actor Context |

## 12. 删除能力验收

以下页面、路由和导航不得出现在目标版本：

- Issue Board；
- Issue Table；
- Issue Properties；
- Labels；
- Subscribers；
- Reactions；
- Due/Start Date；
- Calendar；
- Child Issue UI；
- Autopilot；
- Slack；
- Feishu；
- Mobile；
- Billing；
- Inbox；
- External Webhook 管理。

## 13. 发布门槛

发布前必须全部通过：

- 所有 P0；
- 所有安全类 P1；
- FLOW-01、FLOW-02；
- CM-07；
- RC-01、RC-02；
- TQ-01、TQ-03、TQ-04；
- 无跨 Workspace 数据泄露；
- 无 Leader 自触发无限循环；
- 无运行期间 Comment 永久丢失。
