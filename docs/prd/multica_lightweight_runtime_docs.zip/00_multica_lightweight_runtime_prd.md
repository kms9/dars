# Multica 轻量智能体与小队协作运行时需求文档

> 基础仓库：`kms9/multica`  
> 基准提交：`736fbc8a5f1b22d48354a0e55baa00661e9e4326`  
> 文档目标：保留本地 Daemon、Runtime、Agent、Direct Chat、Squad 与最小 Issue/Comment 协作闭环，删除完整项目管理外围能力。

## 1. 核心结论

目标系统不是完整的项目管理产品，而是：

```text
Workspace
├── Desktop / Web
├── Local Daemon
├── Runtime
├── Agent
├── Direct Chat
├── Squad
├── Lightweight Issue
├── Flat Comment Timeline
└── Durable Task Queue
```

其中：

- `Issue` 是一次 Agent/Squad 协作运行的持久化根对象；
- `Comment` 是委派、结果、补充信息和重入触发事件；
- `Task Queue` 是单次 Agent 调用的可靠执行记录；
- `Squad` 是 Leader、成员、角色、Skills 和 Instructions 的静态组织定义；
- `Daemon` 是本地 Runtime 的执行宿主。

## 2. 产品目标

1. 用户可以通过 Desktop 启动并配对本地 Daemon。
2. Daemon 可以发现、注册和维护本地 Runtime。
3. 用户可以选择 Runtime 创建 Agent。
4. 用户可以和单个 Agent Direct Chat。
5. 用户可以创建 Squad，设置 Leader、成员、Role 和 Instructions。
6. 用户可以向 Squad 提交一项工作。
7. Leader 可以通过 Comment Mention 委派成员。
8. Member 可以执行任务并写回结果 Comment。
9. Member Comment 可以重新唤醒 Leader。
10. Leader 可以继续委派、要求修正或将整体工作推进到 Review。
11. 系统删除 Issue Board、Table、Properties、Labels、Subscribers、Reactions、Autopilot 和外部渠道等外围能力。

## 3. 非目标

本阶段不包含：

- 新建独立 `SquadRun` 数据模型；
- 新建 DAG、BPMN、Temporal 或自动 fan-out/fan-in 引擎；
- 将 Chat Session 立即改造成多 Agent 协作会话；
- 重新设计 Squad 调度协议；
- 保留完整 Linear/Jira 类项目管理能力；
- 立即物理删除所有历史字段和 Migration。

## 4. 核心对象

### 4.1 Workspace

Workspace 是用户、Daemon、Runtime、Agent、Squad、Issue、Comment、Chat Session 和 Task 的隔离边界。

### 4.2 Runtime

Runtime 表示实际执行 Agent 的提供者实例，例如 Codex、Claude Code、OpenCode、Cursor、OpenClaw 或自定义 Runtime Profile。

### 4.3 Agent

Agent 至少保留：

- `name`
- `description`
- `instructions`
- `runtime_id`
- `runtime_mode`
- `model`
- `thinking_level`
- `service_tier`
- `skills`
- `mcp_config`
- `runtime_config`
- `custom_args`
- `custom_env`
- `max_concurrent_tasks`
- `permission_mode`

### 4.4 Squad

Squad 至少保留：

- `name`
- `description`
- `leader_id`
- `instructions`
- Agent/Human Members
- Member Role
- Archive 状态

Squad 本身不是可执行进程。所有 Squad 工作先路由到 Leader，再由 Leader 通过 Comment Mention 派发成员。

### 4.5 Lightweight Issue

Issue 负责：

- 总目标；
- 描述和验收要求；
- 当前 Assignee；
- 整体状态；
- Comments；
- Agent Tasks；
- 发起者和归因。

### 4.6 Lightweight Comment

Comment 负责：

- 用户补充；
- Leader 委派；
- Member 结果；
- Leader 判断；
- Mention 触发；
- Leader 重入；
- 运行期间新消息补偿。

### 4.7 Agent Task

Agent Task 负责单次执行状态：

```text
queued → dispatched → running → completed/failed/cancelled
```

必须保证：

```text
Task completed != Issue completed
```

Leader 的一次 Task 可能只完成了成员委派。

## 5. 核心流程

### 5.1 Direct Chat

```text
User Message
→ chat_message
→ Chat Task
→ Daemon Claim
→ Runtime Execute
→ Streaming
→ Assistant Message
```

Direct Chat 不依赖 Issue。

### 5.2 Squad Run

```text
Create Issue assigned to Squad
→ Enqueue Leader Task
→ Leader reads Issue + Comments + Squad Briefing
→ Leader posts Comment with @Member mention
→ Enqueue Member Task
→ Member executes and posts result Comment
→ Re-trigger Leader
→ Leader continues or sets Issue in_review
```

## 6. 状态模型

建议后端继续保留：

```text
backlog
todo
in_progress
in_review
done
cancelled
```

最小 UI 可以只突出：

```text
Active / Review / Done / Cancelled
```

## 7. 必须保留的可靠性能力

- Mention Parser；
- Assigned Squad Leader Trigger；
- Leader Self-trigger Guard；
- Pending Task Dedup；
- Comment Reconciliation；
- Workspace Tenant Guard；
- Task Complete/Fail 幂等；
- Result Comment/Fallback Comment；
- Session/WorkDir Resume；
- Runtime Offline 处理；
- Task Retry；
- Realtime Task/Comment/Issue Events。

## 8. 页面范围

保留：

- Desktop Daemon；
- Runtime；
- Agent List/Create/Detail；
- Direct Chat；
- Squad List/Create/Detail；
- 轻量任务创建；
- 轻量 Squad Run Detail。

删除：

- Issue Board；
- Issue Table；
- Issue Properties；
- Labels；
- Subscribers；
- Reactions；
- Calendar；
- Complex Search；
- Child Issue Tree；
- Autopilot；
- Slack/Feishu；
- Mobile；
- Billing；
- Inbox。

## 9. 最终验收主流程

1. Desktop 启动 Daemon。
2. Daemon 注册本地 Runtime。
3. 用户选择 Runtime 创建 Leader、Backend Agent 和 Test Agent。
4. 用户创建 Squad。
5. 用户提交 Issue 给 Squad。
6. Leader 被触发并 Mention Backend Agent。
7. Backend Agent 完成并写结果 Comment。
8. Leader 被重新触发并 Mention Test Agent。
9. Test Agent 完成并写验证 Comment。
10. Leader 再次被触发并将 Issue 置为 `in_review`。
11. 用户能看到完整 Timeline、Tasks、Runtime 和最终结果。
