# Multica 代码保留、裁剪与删除清单

> 基准提交：`736fbc8a5f1b22d48354a0e55baa00661e9e4326`

## 1. 分类定义

| 分类 | 含义 |
|---|---|
| 保留 | 目标系统运行的硬依赖 |
| 裁剪 | 文件或模块保留，但删除非核心分支 |
| 停用 | 路由/UI 不再暴露，代码可暂时存在 |
| 删除 | 解耦完成后可以从目标代码库移除 |

## 2. Desktop

### 保留

```text
apps/desktop/src/main/**
apps/desktop/src/preload/**
apps/desktop/src/renderer/**
apps/desktop/electron.vite.config.*
apps/desktop/package.json
```

必须保留：

- Electron Main/Preload/Renderer；
- Token Sync；
- Daemon Auto Start；
- Daemon Start/Stop/Restart；
- Health Check；
- CLI 发现、下载和升级；
- Desktop Profile；
- Daemon 日志；
- IPC API。

### 裁剪

- 删除 Issue Board、Inbox、Billing、External Integration 入口；
- Renderer 只挂载目标 Web Views。

## 3. Daemon 与 Runtime

### 保留

```text
server/internal/daemon/**
server/internal/daemonws/**
server/internal/handler/daemon.go
server/internal/handler/daemon_ws.go
server/pkg/agent/**
server/pkg/protocol/**
server/cmd/multica/
```

保留 Register、Heartbeat、Discovery、Runtime Profile、Claim、Start、Progress、Messages、Usage、Complete、Fail、Cancel、Session、WorkDir、Orphan Recovery 和 WS Wakeup。

### 删除候选

若仅支持本地 Runtime：

```text
server/internal/cloudruntime/**
Cloud Fleet/Gateway
Cloud Runtime 购买和配置 UI
```

## 4. Agent

### 保留

```text
server/internal/handler/agent.go
server/internal/handler/agent_access.go
server/pkg/db/queries/agent.sql
Agent Skills
Runtime Profile
Agent Env/MCP/Config
```

保留 Create/Get/List/Update/Archive/Restore、Runtime 绑定、Model、Skills、MCP、Env、Invocation Permission 和 Runtime Required Gate。

## 5. Direct Chat

### 保留

```text
server/internal/handler/chat.go
server/pkg/db/queries/chat.sql
Chat Realtime Events
TaskService Chat 分支
packages/views/chat/**
packages/core/chat/**
```

### 裁剪

可停用：

- Project Context；
- Chat Quick Actions；
- External Channel Binding；
- Channel Media；
- 非必要 Agent Intro。

## 6. Squad

### 保留

```text
server/internal/handler/squad.go
server/internal/handler/squad_briefing.go
server/pkg/db/queries/squad.sql
server/internal/service/builtin_skills/multica-squads/**
server/cmd/multica/cmd_squad.go
packages/views/squads/**
```

保留 Squad CRUD、Leader、Members、Role、Instructions、Roster、Skills、Leader Briefing、Leader Routing、Readiness、Dedup、Self-trigger Guard 和 Squad Activity。

### 裁剪

删除或隔离：

- Active Issues 展示；
- Issue 统计；
- Archive 时转移 Issue Assignee；
- Autopilot Assignee Transfer；
- Child Issue/Stage；
- 通用 Activity Feed。

## 7. Lightweight Issue

### 保留或拆出 Core

```text
server/internal/handler/issue.go
server/internal/handler/issue_trigger.go
server/pkg/db/queries/issue.sql
server/cmd/multica/cmd_issue.go
```

仅保留：

- Create；
- Get；
- Update Title/Description；
- Update Assignee；
- Update Status；
- Squad Assignment Trigger；
- List Tasks；
- Workspace Guard；
- Assignee Validation。

### 删除

```text
server/internal/handler/issue_table_*.go
Issue Board/Table/Group/Facet
Properties
Labels
Subscribers
Reactions
Due/Start Date
Calendar
Complex Search
Bulk Actions
Assignee Frequency
VCS Issue Link
Child Progress
```

## 8. Lightweight Comment

### 保留

```text
server/internal/handler/comment.go
server/pkg/db/queries/comment.sql
Mention Parser
Comment Trigger Pipeline
Comment Reconciliation
```

仅保留 Add、Flat List、Get、Mention Trigger、Assigned Squad Leader Trigger、Self-trigger Guard、Dedup、Reconciliation、Workspace Integrity 和 `source_task_id`。

### 删除

- Nested Thread；
- Root Thread；
- Thread Pagination；
- Resolve/Unresolve；
- Reactions；
- Quick Actions；
- Draft；
- Thread Ranking；
- Comment Search。

## 9. TaskService

`server/internal/service/task.go` 不应整体删除。

### 必须保留

- Chat Task；
- Issue Task；
- Squad Leader Task；
- Mention Member Task；
- Claim/Start/Messages/Complete/Fail/Cancel/Retry；
- Session/WorkDir；
- Usage；
- Realtime；
- Workspace Resolution；
- Comment Reconciliation；
- Result Delivery。

### 删除分支

- Autopilot；
- Quick Create；
- External Channel；
- Child Done；
- 项目管理 Analytics；
- Thread/Quick Action 相关分支。

### 推荐边界

```text
task_core.go
task_claim.go
task_chat.go
task_issue_core.go
task_comment_trigger.go
task_squad.go
task_retry.go
task_realtime.go
```

## 10. Router

### 保留

- Auth/Workspace；
- Daemon/Runtime；
- Agent；
- Chat；
- Squad；
- Lightweight Issue；
- Lightweight Comment；
- Task；
- Realtime。

### 删除

- Issue Table/Facet/Group；
- Properties；
- Labels；
- Subscribers；
- Reactions；
- Quick Actions；
- Autopilot；
- Channels；
- Lark；
- Slack；
- Billing；
- Inbox；
- External Webhooks。

## 11. Frontend

### 保留

```text
packages/views/agents/**
packages/views/chat/**
packages/views/squads/**
packages/core/agents/**
packages/core/chat/**
packages/core/api/**
packages/core/realtime/**
packages/ui/**
```

### 裁剪保留

`packages/views/issues/**` 与 `packages/core/issues/**` 仅保留：

- Lightweight Run Create；
- Lightweight Run Detail；
- Flat Comment Timeline；
- Comment Composer；
- Task Execution List；
- Status；
- Assignee Squad。

### 共享组件迁出

- Picker；
- Agent Permission Helper；
- Timeline Row；
- Task Status Pill；
- Markdown/Avatar。

目标位置：

```text
packages/ui/**
packages/views/common/**
packages/core/agents/**
```

## 12. 整体删除

```text
apps/mobile/**
Autopilot
Slack
Lark/Feishu
Channel Engine
Billing/Stripe
Inbox
Notifications
Issue Board/Table
Properties
Labels
Subscribers
Reactions
External Webhooks
Complex Analytics
```

## 13. 保留判定

模块只有满足以下至少一项才保留：

1. Daemon/Runtime 配对；
2. Agent 创建或执行；
3. Direct Chat；
4. Leader—Member—Leader 闭环；
5. Workspace 安全隔离；
6. Task 可靠执行和恢复；
7. 目标页面直接依赖。
